---
project: "[[Sample External Project]]"
description: Weekly meeting
date: 2025-10-09
time: 17:31
attendees:
duration: 1.5
type: meeting
---
# Sample External Project - Weekly meeting

Back: [[Meetings.base]]

---

**Notes**
- point 1
- point 2
- point 3

**Action points:**
- [ ] task 1
- [ ] task 2
- [ ] task 3