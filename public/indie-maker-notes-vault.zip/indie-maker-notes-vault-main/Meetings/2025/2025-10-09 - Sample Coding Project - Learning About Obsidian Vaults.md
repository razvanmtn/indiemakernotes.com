---
project: "[[Sample Coding Project]]"
description: Learning About Obsidian Vaults
date: 2025-10-09
time: 16:55
attendees:
  - "[[Razvan Muntian]]"
duration: 1
---
# 2025-10-09 - Sample Coding Project - Learning About Obsidian Vaults

Back: [[Meetings.base]]

---

**Notes**
- point 1
- point 2
- point 3

**Action points:**
- [ ] task 1
- [ ] task 2
- [ ] task 3