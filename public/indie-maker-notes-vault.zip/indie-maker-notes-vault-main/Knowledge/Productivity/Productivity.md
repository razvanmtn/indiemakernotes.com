# Productivity

Back: [[Home]]

---

You're more productive if you aim for long-term growth.

**References:**
- [[James Clear - Atomic Habits#^039df2]]
