---
author: "[[James Clear]]"
title: "James Clear - Atomic Habits"
link: "https://atomichabits.com"
---
# James Clear - James Clear - Atomic Habits

**Link:** https://atomichabits.com

Back: [[Bibliography.base]]

---

**Notes:**

- Small daily habits compound over time, leading to big results — tiny changes can create remarkable long-term growth.  ^039df2
- Focus on systems, not goals — success comes from consistent processes, not just setting targets.
- Habits are formed through cues, cravings, responses, and rewards — the habit loop.
- Make good habits obvious, attractive, easy, and satisfying to stick with them.
- Make bad habits invisible, unattractive, hard, and unsatisfying to break them.
- Environment shapes behavior — design spaces that make good habits easy and bad ones hard.
- Identity-based habits last longer — act like the person you want to become, not just chase outcomes.
- Habits are the compound interest of self-improvement — small gains multiply with consistency.
- Tracking progress helps habits stick — what gets measured gets improved.
- Reflection and review strengthen growth — regularly evaluate your habits to adjust and improve.