---
project: "[[Sample External Project]]"
description: "1004"
status: backlog
created_date: 2025-10-09
created_time: 17:49
priority: medium
type: task
category: misc
duration: 5
---
# Sample External Project - 1004

Back: [[Tasks.base]]

---