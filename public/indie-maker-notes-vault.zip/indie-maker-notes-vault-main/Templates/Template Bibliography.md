---
author: "[[{{value:author}}]]"
title: "{{value:title}}"
link: "{{value:link}}"
---
# {{value:author}} - {{value:title}}

**Link:** {{value:link}}

Back: [[Bibliography.base]]

---

**Notes:**

- 