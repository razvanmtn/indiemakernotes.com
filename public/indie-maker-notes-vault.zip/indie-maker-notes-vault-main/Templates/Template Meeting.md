---
project: "[[{{value:project}}]]"
description: "{{value:description}}"
date: "{{date}}"
time: "{{time}}"
attendees:
duration: 0
type: meeting
---
# {{value:project}} - {{value:description}}

Back: [[Meetings.base]]

---

**Notes**
- point 1
- point 2
- point 3

**Action points:**
- [ ] task 1
- [ ] task 2
- [ ] task 3