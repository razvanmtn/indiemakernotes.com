---
project: "[[{{value:project}}]]"
description: "{{value:description}}"
status: backlog
created_date: "{{date}}"
created_time: "{{time}}"
priority: medium
type: task
category: misc
duration: 0
---
# {{value:project}} - {{value:description}}

Back: [[Tasks.base]]

---