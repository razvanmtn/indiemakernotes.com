# Home

---

**Actions:**

```button
name Create Task
type command
action QuickAdd: Create Task
```

```button
name Create Meeting
type command
action QuickAdd: Create Meeting
```

```button
name Create Bibliography
type command
action QuickAdd: Create Bibliography
```

```button
name Create Contact
type command
action QuickAdd: Create Contact
```

**General Links:**

- [[Draft]]
- [[Bibliography.base]]
- [[Contacts.base]]
- [[Meetings.base]]

**Projects:**

- [[Newsletter]]
- [[Sample Coding Project]]
- [[Sample External Project]]