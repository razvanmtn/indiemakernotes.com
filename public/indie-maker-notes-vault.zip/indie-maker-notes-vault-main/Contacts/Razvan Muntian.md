# Razvan Muntian

Back: [[Contacts.base]]

---

**Contact**
- Email:
- Phone Number:
- Company:
- Interests: indie making, open source, coding

**Links**
- Website: https://razvanmuntian.com
- Newsletter: https://razvanmuntian.substack.com/
- X/Twitter: https://x.com/razvanmuntian
- LinkedIn: https://www.linkedin.com/in/razvanmuntian/
- GitHub: https://github.com/razvanmtn