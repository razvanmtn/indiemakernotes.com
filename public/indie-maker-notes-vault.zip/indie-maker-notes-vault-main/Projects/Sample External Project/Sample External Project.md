# Sample External Project

*This is an example on how you can create a project for time tracking only, without managing all the tasks locally. As a freelancer or contractor, most of the time the tasks are managed in Jira or other platforms.*

Back: [[Home]]

---

- [[Sample External Project Report.base]]