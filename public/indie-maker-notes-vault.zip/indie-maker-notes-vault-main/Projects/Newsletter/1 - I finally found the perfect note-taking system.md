# I finally found the perfect note-taking system

Back: [[Newsletter]]

---

**What's the purpose?**

- talk about indiemakernotes.com

**Title ideas**

- This is my new open source project - a note-taking configuration
- I finally found the perfect note-taking system

**Subtitle:**

- We've all been there: notes scattered everywhere, no structure or system, information overload. I created a note-taking system for indie makers!

---

Hello friend,

If there's one thing that boosted my productivity drastically, that's the system and note taking app that I came up with.

This post and the next one will be about my workflow.

In this newsletter I'm presenting the idea, how I ended up with this system. In the next one I'll present you the actual system to you.

So make sure you don't miss it. Subscribe to the newsletter, and let's get started.

Read the rest of the post: https://razvanmuntian.com/blog/i-finally-found-the-perfect-note/