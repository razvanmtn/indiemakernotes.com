# Draft

*This is a file that you can use whenever you need to jot down something really quick and you don't know where exactly to add this.*

*Make sure every once in a while you empty this file, by moving the ideas and notes to the appropriate place*

Back: [[Home]]

---